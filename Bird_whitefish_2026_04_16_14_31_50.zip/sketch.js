
function setup() {
  createCanvas(400, 400);
}
let olhoX;
let olhoY;

function draw() {
  background('#DA00FF');
  fill('#03A9F4');
  circle(200,200,300); //rosto
  fill('white');
  circle(150,150,60);  //olho esquerdo
  circle(250,150,60);  //olho direito 
  line(150,270,250,235); //boca
  fill('rgb(68,194,54)');
   triangle(200,180,170,220,220,207); //nariz
   line(123,115,178,113); //sobrancelha esquerda
   line(225,116,279,106); //sobrancelha direita
//circle(150,150,10)      // pupila esquerda
 // circle(250,150,10)    // pupila direita
  
  olhoX = map(mouseX,0,400,132,166);
  olhoY = map (mouseY,0,400,133,169); 
  
  circle(olhoX,olhoY,10);
  circle(olhoX+100,olhoY,10);
  if(mouseIsPressed){
     console.log(mouseX,mouseY)
     }
} 